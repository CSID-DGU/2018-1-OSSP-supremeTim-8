package com.tetris.main;

import com.tetris.window.*;

public class TetrisMain{
	public static void main(String[] args){
		new Tetris();
	}
}
